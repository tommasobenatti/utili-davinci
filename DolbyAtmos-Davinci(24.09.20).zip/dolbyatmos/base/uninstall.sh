#!/system/bin/sh


# Dolby Atmos™ partition file restoration
# gh


mount_filesystems() {
  mount -o rw,remount / 2>/dev/null
  if [ "$BOOTMODE" ]; then
    mirror=/sbin/.magisk/mirror
    sysroot=$mirror/system_root
    sys=$(realpath $mirror/system)
    ven=$(realpath $mirror/vendor)
    mount -o rw,remount $sysroot 2>/dev/null
    mount -o rw,remount $sys 2>/dev/null
    mount -o rw,remount $ven 2>/dev/null
  else
    mount -o rw,remount /system
    mount -o rw,remount /vendor 2>/dev/null
    sys=/system
    if [ -L /vendor ]; then
      ven=$sys/vendor
    else
      ven=/vendor
    fi
  fi
}

ext=bak
filecontexts=$ven/etc/selinux/vendor_file_contexts
servicecontexts=$ven/etc/selinux/vendor_hwservice_contexts
sysmanifest=$sys/etc/vintf/manifest.xml
venmanifest=$ven/etc/vintf/manifest.xml
for file in $filecontexts $servicecontexts $sysmanifest $venmanifest; do
  if [ -e "$file.$ext" ]; then
    cp $file.$ext $file
	md5_restored=$(md5sum $file)
	md5_backup=$(md5sum $file$ext)
	if [ "$md5_restored" ] && [ "$md5_restored" = "$md5_backup" ] ; then
		rm $file.$ext
	fi
  fi
done

mount -o ro,remount /system 2>/dev/null
mount -o ro,remount /vendor 2>/dev/null
